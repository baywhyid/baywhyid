
# Notaweb

Blog pribadi dengan gaya minimalis klasik. Dibuat menggunakan HTML dan CSS sederhana.
